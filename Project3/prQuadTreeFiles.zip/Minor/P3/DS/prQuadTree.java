package Minor.P3.DS;
import java.io.FileWriter;
import java.util.Vector;
   
// The test harness will belong to the following package; the quadtree
// implementation must belong to it as well.  In addition, the quadtree
// implementation must specify package access for the node types and tree
// members so that the test harness may have access to it.
//

public class prQuadTree< T extends Compare2D<? super T> > {
   
   // You must use a hierarchy of node types with an abstract base
   // class.  You may use different names for the node types if
   // you like (change displayHelper() accordingly).
   abstract class prQuadNode { }

   class prQuadLeaf extends prQuadNode {
      Vector<T> Elements;
      
      public prQuadLeaf() { 
      }
   }

   class prQuadInternal extends prQuadNode {
      prQuadNode NW, NE, SE, SW;
      
      public prQuadInternal() { 
      }
   }
    
   prQuadNode root;
   long xMin, xMax, yMin, yMax;
   
   // Initialize quadtree to empty state, representing the specified region.
   public prQuadTree(long xMin, long xMax, long yMin, long yMax) {
      
   }
    
   // Pre:   elem != null
   // Post:  If elem lies within the tree's region, and elem is not already 
   //        present in the tree, elem has been inserted into the tree.
   // Return true iff elem is inserted into the tree. 
   public boolean insert(T elem) {
      return false;
   }

    
   // Pre:  elem != null
   // Post: If elem lies in the tree's region, and a matching element occurs
   //       in the tree, then that element has been removed.
   // Returns true iff a matching element has been removed from the tree.
   public boolean delete(T Elem) {
      return false;
   }

   // Pre:  elem != null
   // Returns reference to an element x within the tree such that 
   // elem.equals(x)is true, provided such a matching element occurs within
   // the tree; returns null otherwise.
   public T find(T Elem) {
      return null;
   }
 
   // Pre:  xLo, xHi, yLo and yHi define a rectangular region
   // Returns a collection of (references to) all elements x such that x is 
   //in the tree and x lies at coordinates within the defined rectangular 
   // region, including the boundary of the region.
   public Vector<T> find(long xLo, long xHi, long yLo, long yHi) {
      return null;      
   }
}
